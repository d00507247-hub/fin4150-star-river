#!/usr/bin/env python3
"""Solve time-value-of-money problems for any one of the five standard variables.

Relationship used (all cash flows in the same sign convention, i.e. a positive
PMT and a positive PV both grow into a positive FV):

    FV = PV * (1 + r)**n  +  PMT * ((1 + r)**n - 1) / r * (1 + r * due)

where `due` is 1 for beginning-of-period payments (--due) and 0 otherwise.
When r == 0 the annuity factor collapses to n.

With --perpetuity the stream never ends and the relationship becomes

    PV = PMT / (r - g) * (1 + r * due)

where g is --growth (default 0). This is the Gordon growth model; it requires
r > g, and fv and n do not apply.

Examples:
    tvm.py --solve fv   --pmt 2400 --rate 0.07 --n 40 --pv 0
    tvm.py --solve pv   --perpetuity --pmt 3 --rate 0.12 --growth 0.03
    tvm.py --solve pmt  --fv 1000000 --pv 0 --rate 0.06 --n 30 --due
    tvm.py --solve rate --fv 479124 --pv 0 --pmt 2400 --n 40
"""

import argparse
import math
import sys


def annuity_factor(rate, n, due):
    """Future value of n payments of 1."""
    if rate == 0:
        factor = n
    else:
        factor = ((1 + rate) ** n - 1) / rate
    return factor * (1 + rate * due)


def future_value(pv, pmt, rate, n, due):
    return pv * (1 + rate) ** n + pmt * annuity_factor(rate, n, due)


def solve_fv(pv, pmt, rate, n, due):
    return future_value(pv, pmt, rate, n, due)


def solve_pv(fv, pmt, rate, n, due):
    return (fv - pmt * annuity_factor(rate, n, due)) / (1 + rate) ** n


def solve_pmt(fv, pv, rate, n, due):
    factor = annuity_factor(rate, n, due)
    if factor == 0:
        raise ValueError("cannot solve for pmt: annuity factor is zero (n = 0)")
    return (fv - pv * (1 + rate) ** n) / factor


def solve_n(fv, pv, pmt, rate, due):
    if rate == 0:
        if pmt == 0:
            raise ValueError("cannot solve for n: rate and pmt are both zero")
        return (fv - pv) / pmt
    # FV + k = (PV + k) * (1 + r)**n, where k absorbs the annuity term.
    k = pmt * (1 + rate * due) / rate
    numer, denom = fv + k, pv + k
    if denom == 0 or numer / denom <= 0:
        raise ValueError("no solution for n with these inputs")
    return math.log(numer / denom) / math.log(1 + rate)


def solve_rate(fv, pv, pmt, n, due):
    """Bisect on rate; the FV function is monotonic in r for ordinary inputs."""
    if n <= 0:
        raise ValueError("cannot solve for rate: n must be positive")

    def f(r):
        return future_value(pv, pmt, r, n, due) - fv

    lo, hi = -0.9999, 0.0001
    f_lo = f(lo)
    # Expand the upper bound until the root is bracketed.
    for _ in range(200):
        if f_lo * f(hi) <= 0:
            break
        hi *= 2
        if hi > 1e6:
            raise ValueError("no rate found that satisfies these inputs")
    else:
        raise ValueError("no rate found that satisfies these inputs")

    for _ in range(200):
        mid = (lo + hi) / 2
        f_mid = f(mid)
        if f_mid == 0:
            return mid
        if f_lo * f_mid < 0:
            hi = mid
        else:
            lo, f_lo = mid, f_mid
    return (lo + hi) / 2


# --- Perpetuities (--perpetuity), level or growing --------------------------
#
# A payment stream with no end date. With growth g < r:
#
#     PV = PMT / (r - g) * (1 + r * due)
#
# PMT is the payment one period from now (D1 in the Gordon growth model);
# --due instead places the first payment today. Setting g = 0 gives the level
# perpetuity PV = PMT / r. There is no FV or n for a perpetuity.


def check_convergence(rate, growth):
    if rate <= growth:
        raise ValueError(
            "a perpetuity only has a finite value when rate > growth "
            "(got rate = %g, growth = %g)" % (rate, growth))


def perp_pv(pmt, rate, growth, due):
    check_convergence(rate, growth)
    return pmt / (rate - growth) * (1 + rate * due)


def perp_pmt(pv, rate, growth, due):
    check_convergence(rate, growth)
    return pv * (rate - growth) / (1 + rate * due)


def perp_rate(pv, pmt, growth, due):
    # pv * (r - g) = pmt * (1 + r * due)  ->  r * (pv - pmt*due) = pmt + pv*g
    denom = pv - pmt * due
    if denom == 0:
        raise ValueError("no rate satisfies these inputs")
    rate = (pmt + pv * growth) / denom
    check_convergence(rate, growth)
    return rate


def perp_growth(pv, pmt, rate, due):
    if pv == 0:
        raise ValueError("cannot solve for growth: pv is zero")
    growth = rate - pmt * (1 + rate * due) / pv
    check_convergence(rate, growth)
    return growth


def parse_rate(text):
    """Accept either a decimal (0.07) or a percentage ('7%')."""
    text = text.strip()
    if text.endswith("%"):
        return float(text[:-1]) / 100
    return float(text)


REQUIRED = {
    "fv": ("pv", "pmt", "rate", "n"),
    "pv": ("fv", "pmt", "rate", "n"),
    "pmt": ("fv", "pv", "rate", "n"),
    "n": ("fv", "pv", "pmt", "rate"),
    "rate": ("fv", "pv", "pmt", "n"),
}

# In perpetuity mode there are only four variables and no n or fv. --growth is
# optional everywhere it is not the unknown, defaulting to 0 (level perpetuity).
PERP_REQUIRED = {
    "pv": ("pmt", "rate"),
    "pmt": ("pv", "rate"),
    "rate": ("pv", "pmt"),
    "growth": ("pv", "pmt", "rate"),
}


def report(name, value):
    if name in ("rate", "growth"):
        print("%s = %.6f (%.4f%%)" % (name, value, value * 100))
    elif name == "n":
        print("n = %.6f" % value)
    else:
        print("%s = %s" % (name, format(value, ",.2f")))


def run_perpetuity(parser, args):
    if args.solve not in PERP_REQUIRED:
        parser.error("--solve %s is not defined for a perpetuity (it has no "
                     "maturity date, so fv and n do not exist)" % args.solve)
    for name in ("fv", "n"):
        if getattr(args, name) is not None:
            parser.error("--%s cannot be used with --perpetuity" % name)

    needed = PERP_REQUIRED[args.solve]
    missing = [name for name in needed if getattr(args, name) is None]
    if missing:
        parser.error("--solve %s --perpetuity requires %s (missing: %s)"
                     % (args.solve, ", ".join("--" + x for x in needed),
                        ", ".join("--" + x for x in missing)))
    if getattr(args, args.solve) is not None:
        parser.error("--%s was given but is the value being solved for" % args.solve)

    due = 1 if args.due else 0
    growth = 0.0 if args.growth is None else args.growth

    try:
        if args.solve == "pv":
            result = perp_pv(args.pmt, args.rate, growth, due)
        elif args.solve == "pmt":
            result = perp_pmt(args.pv, args.rate, growth, due)
        elif args.solve == "rate":
            result = perp_rate(args.pv, args.pmt, growth, due)
        else:
            result = perp_growth(args.pv, args.pmt, args.rate, due)
    except (ValueError, ZeroDivisionError, OverflowError) as exc:
        print("error: %s" % exc, file=sys.stderr)
        return 1

    report(args.solve, result)
    return 0


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Solve for one time-value-of-money variable given the other four.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="Rates may be given as 0.07 or 7%%. Use --due for annuity-due "
               "(beginning-of-period) payments. Use --perpetuity (optionally with "
               "--growth) for a stream with no end date.",
    )
    parser.add_argument("--solve", required=True,
                        choices=sorted(set(REQUIRED) | set(PERP_REQUIRED)),
                        help="which variable to solve for ('growth' requires --perpetuity)")
    parser.add_argument("--fv", type=float, help="future value")
    parser.add_argument("--pv", type=float, help="present value")
    parser.add_argument("--pmt", type=float, help="payment per period")
    parser.add_argument("--n", type=float, help="number of periods")
    parser.add_argument("--rate", type=parse_rate, help="rate per period, e.g. 0.07 or 7%%")
    parser.add_argument("--growth", type=parse_rate,
                        help="payment growth rate per period (--perpetuity only; default 0)")
    parser.add_argument("--due", action="store_true",
                        help="payments at the beginning of each period (default: end)")
    parser.add_argument("--perpetuity", action="store_true",
                        help="payments continue forever; requires rate > growth, no --n or --fv")
    args = parser.parse_args(argv)

    if args.perpetuity:
        return run_perpetuity(parser, args)

    if args.growth is not None:
        parser.error("--growth is only supported with --perpetuity; this script "
                     "does not handle finite growing annuities")
    if args.solve == "growth":
        parser.error("--solve growth is only valid with --perpetuity")

    needed = REQUIRED[args.solve]
    missing = [name for name in needed if getattr(args, name) is None]
    if missing:
        parser.error("--solve %s requires %s (missing: %s)"
                     % (args.solve, ", ".join("--" + x for x in needed),
                        ", ".join("--" + x for x in missing)))
    extra = getattr(args, args.solve)
    if extra is not None:
        parser.error("--%s was given but is the value being solved for" % args.solve)

    due = 1 if args.due else 0
    values = {name: getattr(args, name) for name in needed}

    try:
        if args.solve == "fv":
            result = solve_fv(values["pv"], values["pmt"], values["rate"], values["n"], due)
        elif args.solve == "pv":
            result = solve_pv(values["fv"], values["pmt"], values["rate"], values["n"], due)
        elif args.solve == "pmt":
            result = solve_pmt(values["fv"], values["pv"], values["rate"], values["n"], due)
        elif args.solve == "n":
            result = solve_n(values["fv"], values["pv"], values["pmt"], values["rate"], due)
        else:
            result = solve_rate(values["fv"], values["pv"], values["pmt"], values["n"], due)
    except (ValueError, ZeroDivisionError, OverflowError) as exc:
        print("error: %s" % exc, file=sys.stderr)
        return 1

    report(args.solve, result)
    return 0


if __name__ == "__main__":
    sys.exit(main())
