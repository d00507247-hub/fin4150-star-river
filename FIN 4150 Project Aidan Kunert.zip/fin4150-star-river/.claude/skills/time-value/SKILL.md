---
name: time-value
description: Solve any time-value-of-money question by running scripts/tvm.py — never by mental or hand arithmetic. Use for future value, present value, payment size, number of periods, or implied interest/growth rate; for savings, retirement, annuity, loan, mortgage, lease, bond, CD, sinking-fund, and compound-growth problems; for perpetuities and never-ending payment streams, including stock valuation by the Gordon growth / dividend discount model ("what's a stock paying a $X dividend growing at Y% worth", "value a preferred share", "what growth is priced in"); and whenever a question combines a rate, a term, and a lump sum or recurring payment ("what will $X grow to", "how much do I need to save each month", "what rate would I need", "how long until", "what's that worth today"). Triggers on both explicit finance framing and casual phrasing.
---

# Time value of money

Always compute with `scripts/tvm.py`. Do not do the arithmetic yourself — not in your head, not in a written-out formula, not "approximately." Even when the answer feels obvious or you have solved a similar problem earlier in the conversation, run the script and report what it prints. If several quantities are asked for, run it once per quantity.

## Running it

```bash
python3 .claude/skills/time-value/scripts/tvm.py --solve <fv|pv|pmt|n|rate> [--fv N] [--pv N] [--pmt N] [--n N] [--rate R] [--due]
```

Pass `--solve` plus the four known values; the script prints the fifth. Omit the flag for the variable being solved for — passing it is an error.

- `--rate` accepts a decimal (`0.07`) or a percentage (`7%`). It is the rate **per period**, not per year.
- `--n` is the number of **periods**, not years.
- `--due` switches to beginning-of-period payments. Default is end-of-period (ordinary annuity).
- Sign convention: everything is positive together. A positive `--pv` and a positive `--pmt` grow into a positive `fv`. Do not negate cash flows the way a financial calculator would.
- One consequence: on a loan, where the payment works *against* the balance rather than with it, the script returns a **negative** `pmt`. That is the correct output for this convention — report its magnitude as the payment amount.

## Mapping a question onto the flags

1. **Pick the unknown.** "What will it grow to" → `fv`. "What's it worth today" / "lump sum needed now" → `pv`. "How much per month/year" → `pmt`. "How long" → `n`. "What return do I need" → `rate`.
2. **Convert the period.** If payments are monthly, divide the annual rate by 12 and multiply the years by 12. Same for quarterly (4) and weekly (52). State the conversion in your answer.
3. **Fill in the zeros.** A problem with no starting balance still needs `--pv 0`; a problem with no recurring contribution still needs `--pmt 0`. All four known values are required.
4. **Check timing.** "At the end of each year", or unstated → default. "At the start of each month", "beginning of period", "annuity due" → add `--due`.

## Examples

$2,400 a year for 40 years at 7%, contributed at year end:

```bash
python3 .claude/skills/time-value/scripts/tvm.py --solve fv --pv 0 --pmt 2400 --rate 0.07 --n 40
```

$500 a month for 30 years at 6% annual, contributed at the start of each month — rate becomes 0.06/12, periods become 360:

```bash
python3 .claude/skills/time-value/scripts/tvm.py --solve fv --pv 0 --pmt 500 --rate 0.005 --n 360 --due
```

Monthly payment on a $350,000 mortgage at 6.5% annual over 30 years — the loan is today's `pv`, paid down to a `fv` of 0:

```bash
python3 .claude/skills/time-value/scripts/tvm.py --solve pmt --pv 350000 --fv 0 --rate 0.0054166667 --n 360
```

This prints `pmt = -2,212.24`; the payment is $2,212.24 a month, negative because it runs against the balance.

Rate needed to turn $10,000 into $25,000 in 12 years with no contributions:

```bash
python3 .claude/skills/time-value/scripts/tvm.py --solve rate --pv 10000 --fv 25000 --pmt 0 --n 12
```

## Perpetuities and growing perpetuities

For a stream with no end date, pass `--perpetuity` instead of `--n`, and `--growth` for a payment that rises each period:

    PV = PMT / (rate − growth) × (1 + rate × due)

`--growth` defaults to 0, which is a level perpetuity (`PV = PMT / rate`) — the standard way to value a preferred share or a consol. With a growth rate this is the Gordon growth model / dividend discount model. `fv` and `n` do not exist for a perpetuity and the script rejects them.

Solve for `pv`, `pmt`, `rate`, or `growth` by passing the other three (`--growth` may be omitted when it is 0). `--solve growth` answers "what growth rate does this price imply?" and is only available in perpetuity mode.

A stock paying a $3 dividend a year from now, growing 3% a year, discounted at 12%:

```bash
python3 .claude/skills/time-value/scripts/tvm.py --solve pv --perpetuity --pmt 3 --rate 0.12 --growth 0.03
```

Growth priced into a share trading at $40 that pays a $3 dividend, at a 12% required return:

```bash
python3 .claude/skills/time-value/scripts/tvm.py --solve growth --perpetuity --pv 40 --pmt 3 --rate 0.12
```

Two things to get right when setting these up:

- **`--pmt` is the payment one period from now** (D₁), not the one just paid. If the problem gives the *most recent* dividend (D₀), grow it first: pass `D₀ × (1 + g)`. Say which reading you used, since the two differ by a few percent. Use `--due` only when the first payment arrives today.
- **`rate` must exceed `growth`**, or the value is infinite; the script errors out rather than returning a number. If a question implies growth at or above the discount rate, report that the model does not apply instead of forcing an answer.

The result is sensitive to the `rate − growth` spread, so when the inputs are estimates rather than givens, it is worth noting how much the answer moves if the spread changes.

## Reporting the answer

Give the script's number, then the inputs you used — rate per period, number of periods, and payment timing — so the user can check the setup. If the phrasing left something genuinely ambiguous (annual vs. monthly compounding, whether a starting balance exists), say which reading you used rather than refusing to compute.

The script exits non-zero with an `error:` line when inputs have no solution — for instance solving for `rate` when the target `fv` is unreachable, or for `n` when the balance never gets there. Report that as a real result about the problem, not as a bug to work around by hand.

## Out of scope

This script handles level payments at a constant periodic rate over a fixed term, plus level and growing perpetuities. It does not do irregular cash flows (NPV/IRR over a varying stream), *finite* growing annuities (`--growth` works only with `--perpetuity`, and the script says so), multi-stage dividend models, amortization schedules, or taxes. If a question needs one of those, say so and solve what you can with the script — for example, an amortization schedule can be built by calling it repeatedly, but the per-period interest split is not something it outputs.
