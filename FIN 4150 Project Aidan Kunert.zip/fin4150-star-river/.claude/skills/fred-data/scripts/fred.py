#!/usr/bin/env python3
"""Fetch observations for a FRED economic data series.

Calls https://api.stlouisfed.org/fred/series/observations and prints one row
per observation, oldest first.

The API key is read with os.environ inside this script. The project's .env is
loaded first and takes priority over any pre-existing shell export. The key is
never printed, never written to disk, and never passed on a command line; it is
scrubbed from error output before anything is displayed.

FRED returns "." as the value for an observation with no data — weekends and
holidays in a daily series like DGS10. Those rows are dropped by default;
--show-missing keeps them.

Examples:
    fred.py --series DGS10 --last 10
    fred.py --series DGS10 --start 2026-01-01
    fred.py --series CPIAUCSL --start 2025-01-01 --last 5
"""

import argparse
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime

ENDPOINT = "https://api.stlouisfed.org/fred/series/observations"
ENV_VAR = "FRED_API_KEY"
MISSING = "."

# scripts/ -> fred-data -> skills -> .claude -> project root, where .env lives.
_HERE = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.abspath(os.path.join(_HERE, os.pardir, os.pardir,
                                            os.pardir, os.pardir))


def load_dotenv():
    """Load KEY=VALUE lines from .env into os.environ, overriding existing values.

    .env is the priority source for this project, so a stale shell export must
    not win. Checks the project root, then the working directory; silently does
    nothing when neither has a .env.
    """
    for directory in (PROJECT_ROOT, os.getcwd()):
        path = os.path.join(directory, ".env")
        try:
            with open(path) as handle:
                lines = handle.readlines()
        except IOError:
            continue
        for line in lines:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            name, _, value = line.partition("=")
            os.environ[name.strip()] = value.strip().strip('"').strip("'")
        return


def get_api_key():
    load_dotenv()
    key = os.environ.get(ENV_VAR, "").strip()
    if not key:
        raise ValueError(
            "%s is not set. Put it in .env at the project root or export it."
            % ENV_VAR)
    if key.startswith("replace_me"):
        raise ValueError(
            "%s is still the placeholder value; paste your real key into .env."
            % ENV_VAR)
    return key


def scrub(text, key):
    """Remove the API key from anything headed for the terminal."""
    return text.replace(key, "<redacted>") if key else text


def parse_date(text):
    """Accept only YYYY-MM-DD, the format FRED's date parameters require."""
    try:
        datetime.strptime(text, "%Y-%m-%d")
    except ValueError:
        raise argparse.ArgumentTypeError(
            "%r is not a date in YYYY-MM-DD form" % text)
    return text


def fetch(series, key, start=None, last=None):
    """Return the observations list from FRED, oldest first."""
    params = {
        "series_id": series,
        "api_key": key,
        "file_type": "json",  # the endpoint defaults to xml
    }
    if start is not None:
        params["observation_start"] = start
    if last is not None:
        # Newest-first with a cap is the only way to ask for "the last N".
        params["sort_order"] = "desc"
        params["limit"] = last

    url = ENDPOINT + "?" + urllib.parse.urlencode(params)
    try:
        with urllib.request.urlopen(url, timeout=30) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = ""
        try:
            body = json.loads(exc.read().decode("utf-8"))
            detail = ": %s" % body.get("error_message", "")
        except Exception:
            pass
        raise ValueError("FRED returned HTTP %s%s"
                         % (exc.code, scrub(detail, key)))
    except urllib.error.URLError as exc:
        raise ValueError("could not reach FRED (%s)" % scrub(str(exc.reason), key))

    observations = payload.get("observations", [])
    if last is not None:
        observations = list(reversed(observations))
    return observations


def report(series, observations, show_missing):
    kept = [obs for obs in observations
            if show_missing or obs.get("value") != MISSING]
    dropped = len(observations) - len(kept)

    if not kept:
        print("%s: no observations with data in this range" % series)
        return

    for obs in kept:
        print("%s  %s" % (obs["date"], obs["value"]))

    latest = kept[-1]
    print("\n%s: %s observation%s"
          % (series, len(kept), "" if len(kept) == 1 else "s"), end="")
    if dropped:
        print(", %s missing row%s dropped"
              % (dropped, "" if dropped == 1 else "s"), end="")
    print("\nlatest: %s on %s" % (latest["value"], latest["date"]))


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Fetch observations for a FRED series.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="Reads the API key from %s (see .env). With neither --last nor "
               "--start, returns the 10 most recent observations." % ENV_VAR,
    )
    parser.add_argument("--series", default="DGS10",
                        help="FRED series ID (default: DGS10, 10-year Treasury)")
    parser.add_argument("--last", type=int,
                        help="return only the N most recent observations")
    parser.add_argument("--start", type=parse_date,
                        help="earliest observation date, YYYY-MM-DD")
    parser.add_argument("--show-missing", action="store_true",
                        help="keep rows FRED reports as '.' (no data that day)")
    args = parser.parse_args(argv)

    if args.last is not None and args.last < 1:
        parser.error("--last must be at least 1")
    last = args.last
    if last is None and args.start is None:
        last = 10

    try:
        key = get_api_key()
    except ValueError as exc:
        print("error: %s" % exc, file=sys.stderr)
        return 1

    try:
        observations = fetch(args.series, key, start=args.start, last=last)
    except ValueError as exc:
        print("error: %s" % scrub(str(exc), key), file=sys.stderr)
        return 1

    if not observations:
        print("error: no observations returned for %r (check the series ID)"
              % args.series, file=sys.stderr)
        return 1

    report(args.series, observations, args.show_missing)
    return 0


if __name__ == "__main__":
    sys.exit(main())
