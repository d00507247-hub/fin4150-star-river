---
name: fred-data
description: Look up any economic or financial statistic by running scripts/fred.py against the FRED API — never from memory. Use for current and historical interest rates and yields (10-year Treasury, 2-year, 30-year, fed funds, SOFR, mortgage rates, the yield curve and its spreads), inflation (CPI, core CPI, PCE, breakevens), employment (unemployment rate, payrolls, jobless claims), growth and output (GDP, industrial production, retail sales), money and credit (M2, bank reserves, credit spreads), housing, exchange rates, and commodity prices. Triggers on any question asking what a rate, yield, index, or economic indicator *is* right now ("what's the 10-year at", "where are mortgage rates", "how high is inflation", "what's the current fed funds rate"), on any request for a historical series or a change over time, and on casual phrasing that assumes a number you would otherwise guess at.
---

# FRED economic data

Always get the number by running `scripts/fred.py`. Never answer from memory, never estimate, and never give a range in place of a figure. Model weights are stale by months or years; a yield or price quoted from memory is wrong in a way the user cannot see. Even when you fetched the same series earlier in the conversation, run the script again if the user asks again — and if you genuinely cannot run it, say you don't have the number rather than supplying one.

## Running it

```bash
python3 .claude/skills/fred-data/scripts/fred.py [--series ID] [--last N] [--start YYYY-MM-DD] [--show-missing]
```

- `--series` is a FRED series ID. Defaults to `DGS10` (10-year Treasury).
- `--last N` returns the N most recent observations.
- `--start YYYY-MM-DD` returns everything from that date forward.
- With neither `--last` nor `--start`, you get the 10 most recent observations.
- `--show-missing` keeps rows FRED reports as `.`; they are dropped by default.

The API key is read from `FRED_API_KEY` inside the script, which loads `.env` itself. Never put the key on the command line, never echo it, and never write it into a file.

## Series IDs

| Series | ID |
|---|---|
| 10-year Treasury | `DGS10` |
| 2-year Treasury | `DGS2` |
| 30-year Treasury | `DGS30` |
| 3-month T-bill | `DGS3MO` |
| 10y–2y spread | `T10Y2Y` |
| 10-year TIPS (real) | `DFII10` |
| 10-year breakeven inflation | `T10YIE` |
| Effective fed funds rate | `DFF` |
| SOFR | `SOFR` |
| 30-year fixed mortgage | `MORTGAGE30US` |
| CPI, all items | `CPIAUCSL` |
| Core CPI | `CPILFESL` |
| PCE price index | `PCEPI` |
| Core PCE | `PCEPILFE` |
| Unemployment rate | `UNRATE` |
| Nonfarm payrolls | `PAYEMS` |
| Initial jobless claims | `ICSA` |
| Real GDP | `GDPC1` |
| Retail sales | `RSXFS` |

For anything not listed, search [fred.stlouisfed.org](https://fred.stlouisfed.org) for the ID. The script cannot look one up: a bad ID returns an HTTP 400, not a suggestion.

## Reporting the answer

**Always give the observation date alongside the value.** "The 10-year is 4.78%" is an unsafe claim; "the 10-year was 4.78% on 2026-09-04, the latest observation" is a true one. This is not a formality — FRED publishes on a lag, and the gap is routinely several days.

- **Daily series** lag by one to several business days, and the lag differs between series pulled on the same afternoon — on 2026-09-09, `SOFR` and `T10Y2Y` were current to 09-08 while `DGS10` stopped at 09-04. Never infer one series' freshness from another's; read the date the script prints.
- **Monthly series** (`CPIAUCSL`, `UNRATE`) run one to two reference months behind. On 2026-09-09 the newest CPI observation was dated 2026-07-01 — the July index, not August's.
- **Quarterly series** (`GDPC1`) run a full quarter behind and are revised afterward. On 2026-09-09 the newest real GDP observation was dated 2026-04-01, i.e. Q2.

If the latest observation is more than a few days stale, say so explicitly rather than letting the user assume it is today's number. When a user asks for "today's" rate and the newest observation is older, give the date you have and note that today's has not been published.

Report the value in the series' own units — `DGS10` is already a percent (`4.78` means 4.78%), while `CPIAUCSL` is an index level, not an inflation rate. To get an inflation *rate* from a price index you must compute the change between two observations; do not report an index level as if it were a percentage.

## Missing observations

FRED returns `.` as the value on days a market was closed. Weekends are absent from the series entirely; holidays appear as `.` rows. The script drops these by default and prints how many it dropped.

This matters when asking for the most recent value: the newest row is never a `.` under the default, so `--last 1` is safe. Use `--show-missing` only when the user needs to see the gaps.

## Out of scope

The script reads observations from one series at a time. It does not search for series IDs, fetch series metadata or descriptions, compare two series in one call, or apply FRED's built-in `units` transformations (`pch`, `pc1`) — compute changes yourself from the returned values.

There is no `--end` flag, so a window is always open-ended forward from `--start`. Combining `--start` with `--last` returns the newest N observations *within* that window, not the first N after the start date — to inspect a historical window, use `--start` alone and read the head of the output.
